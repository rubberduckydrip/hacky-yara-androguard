package kotlin;
@Metadata(bv = {1, 0, 3}, d1 = {"kotlin/StandardKt__StandardKt", "kotlin/StandardKt__SynchronizedKt"}, k = 4, mv = {1, 1, 15}, xi = 1)
/* loaded from: classes.dex */
public final class StandardKt extends StandardKt__SynchronizedKt {
    private StandardKt() {
    }
}
