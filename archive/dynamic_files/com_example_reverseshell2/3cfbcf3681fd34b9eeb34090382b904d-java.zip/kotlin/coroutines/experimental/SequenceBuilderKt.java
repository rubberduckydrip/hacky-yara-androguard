package kotlin.coroutines.experimental;

import kotlin.Metadata;
/* compiled from: SequenceBuilder.kt */
@Metadata(bv = {1, 0, 3}, d1 = {"kotlin/coroutines/experimental/SequenceBuilderKt__SequenceBuilderKt"}, k = 4, mv = {1, 1, 15}, xi = 1)
/* loaded from: classes.dex */
public final class SequenceBuilderKt extends SequenceBuilderKt__SequenceBuilderKt {
    private SequenceBuilderKt() {
    }
}
