package kotlin.coroutines.intrinsics;

import kotlin.Metadata;
@Metadata(bv = {1, 0, 3}, d1 = {"kotlin/coroutines/intrinsics/IntrinsicsKt__IntrinsicsJvmKt", "kotlin/coroutines/intrinsics/IntrinsicsKt__IntrinsicsKt"}, k = 4, mv = {1, 1, 15}, xi = 1)
/* loaded from: classes.dex */
public final class IntrinsicsKt extends IntrinsicsKt__IntrinsicsKt {
    private IntrinsicsKt() {
    }
}
