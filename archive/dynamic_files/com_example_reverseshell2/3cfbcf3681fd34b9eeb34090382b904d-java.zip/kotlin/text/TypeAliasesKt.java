package kotlin.text;

import kotlin.Metadata;
/* compiled from: TypeAliases.kt */
@Metadata(bv = {1, 0, 3}, d1 = {"\u0000 \n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000*\u001a\b\u0007\u0010\u0000\"\u00020\u00012\u00020\u0001B\f\b\u0002\u0012\b\b\u0003\u0012\u0004\b\b(\u0004*\u001e\b\u0007\u0010\u0005\"\u00020\u00062\u00020\u0006B\f\b\u0002\u0012\b\b\u0003\u0012\u0004\b\b(\u0007B\u0002\b\b*\u001a\b\u0007\u0010\t\"\u00020\n2\u00020\nB\f\b\u0002\u0012\b\b\u0003\u0012\u0004\b\b(\u0004¨\u0006\u000b"}, d2 = {"Appendable", "Ljava/lang/Appendable;", "Lkotlin/SinceKotlin;", "version", "1.1", "CharacterCodingException", "Ljava/nio/charset/CharacterCodingException;", "1.3", "Lkotlin/ExperimentalStdlibApi;", "StringBuilder", "Ljava/lang/StringBuilder;", "kotlin-stdlib"}, k = 2, mv = {1, 1, 15})
/* loaded from: classes.dex */
public final class TypeAliasesKt {
    public static /* synthetic */ void Appendable$annotations() {
    }

    public static /* synthetic */ void CharacterCodingException$annotations() {
    }

    public static /* synthetic */ void StringBuilder$annotations() {
    }
}
