package kotlin.collections;

import kotlin.Metadata;
@Metadata(bv = {1, 0, 3}, d1 = {"kotlin/collections/SetsKt__SetsJVMKt", "kotlin/collections/SetsKt__SetsKt", "kotlin/collections/SetsKt___SetsKt"}, k = 4, mv = {1, 1, 15}, xi = 1)
/* loaded from: classes.dex */
public final class SetsKt extends SetsKt___SetsKt {
    private SetsKt() {
    }
}
