package kotlin.collections;

import kotlin.Metadata;
@Metadata(bv = {1, 0, 3}, d1 = {"kotlin/collections/MapsKt__MapWithDefaultKt", "kotlin/collections/MapsKt__MapsJVMKt", "kotlin/collections/MapsKt__MapsKt", "kotlin/collections/MapsKt___MapsKt"}, k = 4, mv = {1, 1, 15}, xi = 1)
/* loaded from: classes.dex */
public final class MapsKt extends MapsKt___MapsKt {
    private MapsKt() {
    }
}
