package kotlin.collections.unsigned;

import kotlin.Metadata;
@Metadata(bv = {1, 0, 3}, d1 = {"kotlin/collections/unsigned/UArraysKt___UArraysJvmKt", "kotlin/collections/unsigned/UArraysKt___UArraysKt"}, k = 4, mv = {1, 1, 15}, pn = "kotlin.collections", xi = 1)
/* loaded from: classes.dex */
public final class UArraysKt extends UArraysKt___UArraysKt {
    private UArraysKt() {
    }
}
