package kotlin.collections;

import kotlin.Metadata;
@Metadata(bv = {1, 0, 3}, d1 = {"kotlin/collections/GroupingKt__GroupingJVMKt", "kotlin/collections/GroupingKt__GroupingKt"}, k = 4, mv = {1, 1, 15}, xi = 1)
/* loaded from: classes.dex */
public final class GroupingKt extends GroupingKt__GroupingKt {
    private GroupingKt() {
    }
}
