package kotlin.collections;

import kotlin.Metadata;
/* compiled from: _UCollections.kt */
@Metadata(bv = {1, 0, 3}, d1 = {"kotlin/collections/UCollectionsKt___UCollectionsKt"}, k = 4, mv = {1, 1, 15}, xi = 1)
/* loaded from: classes.dex */
public final class UCollectionsKt extends UCollectionsKt___UCollectionsKt {
    private UCollectionsKt() {
    }
}
