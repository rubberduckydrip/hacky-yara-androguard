package kotlin.sequences;

import kotlin.Metadata;
/* compiled from: _USequences.kt */
@Metadata(bv = {1, 0, 3}, d1 = {"kotlin/sequences/USequencesKt___USequencesKt"}, k = 4, mv = {1, 1, 15}, xi = 1)
/* loaded from: classes.dex */
public final class USequencesKt extends USequencesKt___USequencesKt {
    private USequencesKt() {
    }
}
