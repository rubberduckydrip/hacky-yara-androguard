package kotlin.sequences;

import kotlin.Metadata;
@Metadata(bv = {1, 0, 3}, d1 = {"kotlin/sequences/SequencesKt__SequenceBuilderKt", "kotlin/sequences/SequencesKt__SequencesJVMKt", "kotlin/sequences/SequencesKt__SequencesKt", "kotlin/sequences/SequencesKt___SequencesJvmKt", "kotlin/sequences/SequencesKt___SequencesKt"}, k = 4, mv = {1, 1, 15}, xi = 1)
/* loaded from: classes.dex */
public final class SequencesKt extends SequencesKt___SequencesKt {
    private SequencesKt() {
    }
}
