package kotlin;
@Metadata(bv = {1, 0, 3}, d1 = {"kotlin/PreconditionsKt__AssertionsJVMKt", "kotlin/PreconditionsKt__PreconditionsKt"}, k = 4, mv = {1, 1, 15}, xi = 1)
/* loaded from: classes.dex */
public final class PreconditionsKt extends PreconditionsKt__PreconditionsKt {
    private PreconditionsKt() {
    }
}
