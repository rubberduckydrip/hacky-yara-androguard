package kotlin;
/* compiled from: Exceptions.kt */
@Metadata(bv = {1, 0, 3}, d1 = {"kotlin/ExceptionsKt__ExceptionsKt"}, k = 4, mv = {1, 1, 15}, xi = 1)
/* loaded from: classes.dex */
public final class ExceptionsKt extends ExceptionsKt__ExceptionsKt {
    private ExceptionsKt() {
    }
}
