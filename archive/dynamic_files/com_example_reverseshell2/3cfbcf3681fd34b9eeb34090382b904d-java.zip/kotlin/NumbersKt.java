package kotlin;
@Metadata(bv = {1, 0, 3}, d1 = {"kotlin/NumbersKt__BigDecimalsKt", "kotlin/NumbersKt__BigIntegersKt", "kotlin/NumbersKt__NumbersJVMKt", "kotlin/NumbersKt__NumbersKt"}, k = 4, mv = {1, 1, 15}, xi = 1)
/* loaded from: classes.dex */
public final class NumbersKt extends NumbersKt__NumbersKt {
    private NumbersKt() {
    }
}
